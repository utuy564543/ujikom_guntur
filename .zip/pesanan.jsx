import React, { useState } from "react";
import "./contact.css";

function ContactForm() {
  const [contactInfo, setContactInfo] = useState({
    nama: "",
    makanan: "",
    jumlahmakanan: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setContactInfo((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitting(true); // Set state untuk menandakan bahwa sedang diproses
    console.log(contactInfo);
    // Tambahkan logika untuk menangani pengiriman pesanan
    // Setelah selesai, Anda bisa menyetel kembali isSubmitting ke false
  };

  return (
    <>
      <div className="contact-container">
        <h2>PESAN MAKANAN</h2>
        <div className="contact-container">
          <form onSubmit={handleSubmit} className="contact">
            <div>
              <label htmlFor="nama">Nama:</label>
              <input
                type="text"
                id="nama"
                name="nama"
                value={contactInfo.nama}
                onChange={handleChange}
              />
            </div>
            <div>
              <label htmlFor="makanan">Makanan:</label>
              <input
                type="text"
                id="makanan"
                name="makanan"
                value={contactInfo.makanan}
                onChange={handleChange}
              />
            </div>
            <div>
              <label htmlFor="jumlahmakanan">Jumlah Makanan:</label>
              <input
                type="text"
                id="jumlahmakanan"
                name="jumlahmakanan"
                value={contactInfo.jumlahmakanan}
                onChange={handleChange}
              />
            </div>
            <button type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Sedang Diproses..." : "Submit"}
            </button>
            {/* Tambahkan teks "Tunggu Pesanan..." di bawah tombol */}
            {isSubmitting && <p>Tunggu Pesanan...</p>}
          </form>
        </div>
      </div>
    </>
  );
}

export default ContactForm;

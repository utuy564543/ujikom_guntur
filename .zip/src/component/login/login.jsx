import React, { useState } from "react";
import "./login.css";
import { useNavigate } from "react-router-dom";

function LoginForm() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });

  const [errors, setErrors] = useState({
    username: "",
    password: "",
  });

  const [successMessage, setSuccessMessage] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    let formErrors = {};
    if (formData.username.trim() === "") {
      formErrors.username = "Username harus diisi";
    }
    if (formData.password.trim() === "") {
      formErrors.password = "Password harus diisi";
    }
    setErrors(formErrors);
    if (Object.keys(formErrors).length === 0) {
      // Simulasi logika autentikasi di sini
      if (formData.username === "admin" && formData.password === "") {
        setSuccessMessage("Anda Berhasil Login,");
        // Reset form
        setFormData({
          username: "",
          password: "",
        });
        setErrors({});
        navigate("/projects");
        window.location.reload();
      } else {
        setSuccessMessage(""); // Bersihkan pesan sukses jika gagal login
        setErrors({ password: "Nama pengguna atau kata sandi salah" });
      }
    }
  };

  return (
    <>
      <div className="loginfrom">
        <h2>Login</h2>
        <div className="loginfrom">
          <form onSubmit={handleSubmit} className="login">
            <div>
              <label htmlFor="username">Username:</label>
              <input
                type="text"
                id="username"
                name="username"
                value={formData.username}
                onChange={handleChange}
              />
              {errors.username && (
                <div className="error">{errors.username}</div>
              )}
            </div>
            <div>
              <label htmlFor="password">Password:</label>
              <input
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
              />
              {errors.password && (
                <div className="error">{errors.password}</div>
              )}
            </div>
            <button type="submit">Login</button>
          </form>
          {successMessage && <div className="success">{successMessage}</div>}
        </div>
      </div>
    </>
  );
}

export default LoginForm;

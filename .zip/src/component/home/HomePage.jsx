import React from "react";
import "./HomePage.css"; // Impor file CSS Anda
import { NavLink, Navigate } from "react-router-dom";

function HomePage() {
  return (
    <div className="home">
      <h1>Selamat Datang di Restoran Kami</h1>
      <center>
        <NavLink to={"/login"}>
          <button type="menu">Login</button>
        </NavLink>
      </center>
      {/* <h2>Menu</h2> */}
      <div className="menu-makanan">
        <div className="menu-item">
          {/* <img
              src="https://c4.wallpaperflare.com/wallpaper/779/394/473/30534-ramen-wallpaper-thumb.jpg"
              alt=""
            />
            <h2></h2>
          </div>
          <div className="menu-item">
            <img
              src="https://c4.wallpaperflare.com/wallpaper/779/394/473/30534-ramen-wallpaper-thumb.jpg"
              alt=""
            />
          </div>
          <div className="menu-item">
            <img
              src="https://c4.wallpaperflare.com/wallpaper/779/394/473/30534-ramen-wallpaper-thumb.jpg"
              alt=""
            />
          </div>
          <div className="menu-item">
            <img
              src="https://c4.wallpaperflare.com/wallpaper/779/394/473/30534-ramen-wallpaper-thumb.jpg"
              alt="" */}
        </div>
      </div>
    </div>
  );
}

export default HomePage;

// import React, { useState } from "react";
// import "./HomePage.css"; // Impor file CSS Anda
// import { NavLink } from "react-router-dom";
// import Makanan1 from "../asset/makanan1.jpg";
// import Makanan2 from "../asset/makanan2.jpg";
// import Makanan3 from "../asset/makanan3.jpg";
// import Makanan4 from "../asset/makanan4.jpg";
// import Makanan5 from "../asset/makanan5.jpg";

// function HomePage() {
//   const [searchTerm, setSearchTerm] = useState(""); // State untuk menyimpan input pencarian
//   const [filteredMakanan, setFilteredMakanan] = useState([]); // State untuk menyimpan daftar makanan yang sudah difilter

//   // Daftar makanan
//   const daftarMakanan = [
//     { id: 1, image: Makanan1, name: "Makanan 1" },
//     { id: 2, image: Makanan2, name: "Makanan 2" },
//     { id: 3, image: Makanan3, name: "Makanan 3" },
//     { id: 4, image: Makanan4, name: "Makanan 4" },
//     { id: 5, image: Makanan5, name: "Makanan 5" }
//   ];

//   // Fungsi untuk menangani perubahan input pencarian
//   const handleSearchChange = event => {
//     setSearchTerm(event.target.value); // Update state pencarian
//     // Filter daftar makanan sesuai dengan input pencarian
//     const filtered = daftarMakanan.filter(makanan =>
//       makanan.name.toLowerCase().includes(event.target.value.toLowerCase())
//     );
//     setFilteredMakanan(filtered); // Update state daftar makanan yang sudah difilter
//   };

//   return (
//     <div className="home">
//       <h1>Selamat Datang di Restoran Kami</h1>
//       <center>
//         <NavLink to={"/login"}>
//           <button type="menu">Login</button>
//         </NavLink>
//       </center>
//       <h2>Menu</h2>
//       {/* Input pencarian */}
//       <input
//         type="text"
//         placeholder="Cari makanan..."
//         value={searchTerm}
//         onChange={handleSearchChange}
//       />
//       <div className="menu-makanan">
//         {/* Tampilkan daftar makanan yang sudah difilter */}
//         {filteredMakanan.length > 0 ? (
//           filteredMakanan.map(makanan => (
//             <div key={makanan.id} className="menu-item">
//               <img src={makanan.image} alt={makanan.name} />
//               <h2>{makanan.name}</h2>
//             </div>
//           ))
//         ) : (
//           <p>Tidak ada hasil untuk pencarian ini.</p>
//         )}
//       </div>
//     </div>
//   );
// }

// export default HomePage;

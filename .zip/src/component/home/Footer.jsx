import React from "react";
import "./Footer.css"; // File CSS untuk styling footer

function Footer() {
  return (
    <footer>
      <div className="container">
        <div className="location">
          <h3>Lokasi Kami</h3>
          <p>Jalan Masjid Darussalam GG Kali - Asem Rt 11 / Rw 11 </p>
          <p>Kota Tanggerang selatan kedaung ciputat Timur</p>
          <p>No Telpon 18256782</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;

export default class Project{
    id=""
    name=""
    image=""
    description=""

constructor(initializer){
    this.id = initializer.id;
    this.name = initializer.name;
    this.image = initializer.image;
    this.description = initializer.description;
}

}